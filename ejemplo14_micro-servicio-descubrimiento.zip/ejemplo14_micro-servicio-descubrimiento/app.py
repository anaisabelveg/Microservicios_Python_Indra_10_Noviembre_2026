# Este servicio permite registrar multiples instancias,
# recibir los heartbeats, consultar instancias registradas
# Limpiar automaticamente los registros caducados

from flask import Flask, jsonify, request
from uuid import uuid4
from datetime import datetime, timezone
from threading import RLock

app = Flask(__name__) 

# Registro en memoria, protegido para accesos concurrentes
registry = {}
registry_lock = RLock()

def utc_now():
    return datetime.now(timezone.utc)

def serialize_instance(instance):
    return{
        **instance,
        "last_heartbeat": instance["last_heartbeat"].isoformat()
    }
    
def cleanup_expired():
    # Eliminar las instancias que no hemos obtenido señal en tiempo
    now = utc_now()
    
    # Elimino las instancias registradas que llevan mas de 30 segundos sin emitir señal
    with registry_lock:
        expired = [instance_id 
                   for instance_id, instance in registry.items() 
                   if (now - instance["last_heartbeat"]).total_seconds() > 30]
        
        for instance_id in expired:
            del registry[instance_id]
            

@app.post("/register")
def register():
    data = request.get_json(silent=True) or {}
    
    service_name = data.get("service_name")
    host = data.get("host")
    port = data.get("port")
    
    if not service_name or not host or port is None:
        return jsonify({
            "error": "service_name, host y port son obligatorios"
        }), 400
        
    if not 1 <= port <= 65535:
        return jsonify({
            "error": "puerto fuera de rango"
        }), 400
        
    # podemos comprobar si el service_name es texto y el host tambien
    # tambien que no vengan vacios
    
    # crear la instancia que vamos a registrar
    instance_id = str(uuid4())
    instance = {
        "instance_id": instance_id,
        "service_name": service_name,
        "host": host,
        "port": port,
        "status": "UP",
        "last_heartbeat": utc_now()
    }
    
    # registramos la instancia con bloqueo
    with registry_lock:
        registry[instance_id] = instance
        
    return jsonify(serialize_instance(instance)), 201


@app.put("/heartbeat/<instance_id>")
def heartbeat(instance_id):
    cleanup_expired()
    
    with registry_lock:
        instance = registry.get(instance_id)
        
        if instance is None:
            return jsonify({"error": "Instancia no esta registrada"}), 404
        
        instance["last_heartbeat"] = utc_now()
        instance["status"] = "UP"
        
        return jsonify({
            "instance_id": instance_id,
            "status": "UP"
        })

@app.delete("/register/<instance_id>")
def desregister(instance_id):
    with registry_lock:
        instance = registry.pop(instance_id, None)
        
        if instance is None:
            return jsonify({"error": "Instancia no encontrada"}), 404

        return "", 204

    
@app.get("/services")
def list_services():
    cleanup_expired()
    
    with registry_lock:
        services = {}
        for instance in registry.values():
            name = instance["service_name"]
            services.setdefault(name, []).append(serialize_instance(instance))
            
    return jsonify(services)


@app.get("/services/<service_name>")
def discover_service(service_name):
    cleanup_expired()
    
    with registry_lock:
        instances = [
            serialize_instance(instance)
            for instance in registry.values()
            if instance["service_name"] == service_name
            and instance["status"] == "UP"
        ]
        
    return jsonify({
        "service_name": service_name,
        "instances": instances,
        "count": len(instances)
    })


if __name__ == "__main__":
    # El micro-servicio-descubrimiento se arranca en el puerto 8761
    app.run(host="127.0.0.1", port=8761, debug=False)