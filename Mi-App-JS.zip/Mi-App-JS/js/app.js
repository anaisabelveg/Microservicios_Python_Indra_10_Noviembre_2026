async function login(event){
    event.preventDefault();
    const API_URL = "http://127.0.0.1:8090/api/usuarios/auth/login";

    const username = document.getElementById("usuario").value;
    const password = document.getElementById("password").value;

    try {
        const response = await fetch(API_URL, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                username: username,
                password: password
            })
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(
                data.message || data.error_description ||
                data.error || "Error de autenticación"
            );
        }

        // Recuperar JWT
        const token = data.access_token;

        if (!token) {
            throw new Error("No se ha recibido el access_token");
        }

        // Guardar JWT
        localStorage.setItem("jwt", token);
        console.log("Token almacenado correctamente");

    } catch (error) {
        console.error("Error:", error);
    } 
}

async function todos(){
    // Recuperar el token almacenado en el navegador
    const token = localStorage.getItem("jwt");

    if (!token) {
        console.error("No se encuentra el JWT");
        return;
    }

    try {
        const response = await fetch("http://localhost:8090/api/prods/productos/", {
            method: "GET",
            headers: {
                "Authorization": `Bearer ${token}`,
                "Accept": "application/json"
            }
        });

        if (!response.ok) {
            throw new Error(`Error HTTP: ${response.status}`);
        }

        const productos = await response.json();

        let seccion = document.querySelector("#resultado");
        seccion.innerHTML = "";
        for(let prod of productos){
            seccion.innerHTML += "<b>" + prod.descripcion + "</b><br/>";
        }    

    } catch (error) {
        console.error("Error al consultar todos los productos:", error);
    }
        
}

async function buscar(){
    // Recuperar el token almacenado en el navegador
    const token = localStorage.getItem("jwt");

    if (!token) {
        console.error("No se encuentra el JWT");
        return;
    }

    try {
        const response = await fetch("http://localhost:8090/api/prods/productos/4", {
            method: "GET",
            headers: {
                "Authorization": `Bearer ${token}`,
                "Accept": "application/json"
            }
        });

        if (!response.ok) {
            throw new Error(`Error HTTP: ${response.status}`);
        }

        const prod = await response.json();

        let seccion = document.querySelector("#resultado");
        seccion.innerHTML = "";
        seccion.innerHTML += "<b>" + prod.descripcion + "</b><br/>";
        seccion.innerHTML += "<b>" + prod.precio + "</b><br/>";

    } catch (error) {
        console.error("Error al buscar productos:", error);
    }
}
            
async function crear(){
    // Recuperar el token almacenado en el navegador
    const token = localStorage.getItem("jwt");

    if (!token) {
        console.error("No se encuentra el JWT");
        return;
    }

    try {
        const response = await fetch("http://localhost:8090/api/pedidos/crear/4/cantidad/100", {
            method: "GET",
            headers: {
                "Authorization": `Bearer ${token}`,
                "Accept": "application/json"
            }
        });

        if (!response.ok) {
            throw new Error(`Error HTTP: ${response.status}`);
        }

        const pedido = await response.json();

        let seccion = document.querySelector("#resultado");
        seccion.innerHTML = "";
        seccion.innerHTML += "<b>" + pedido.producto.descripcion + "</b><br/>";
        seccion.innerHTML += "<b>" + pedido.producto.precio + "</b><br/>";
        seccion.innerHTML += "<b>" + pedido.cantidad + "</b><br/>";

    } catch (error) {
        console.error("Error al crear el pedido:", error);
    }
}

async function nuevo(){
    // Recuperar el token almacenado en el navegador
    const token = localStorage.getItem("jwt");

    if (!token) {
        console.error("No se encuentra el JWT");
        return;
    }

    try {
        const response = await fetch("http://localhost:8090/api/prods/productos/", {
            method: "POST",
            headers: {
                "Authorization": `Bearer ${token}`,
                "Accept": "application/json",
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                descripcion: "Prueba",
                precio: 123
            })
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(
                data.message || data.error_description ||
                data.error || "Error al crear nuevo producto"
            );
        }

        let seccion = document.querySelector("#resultado");
        seccion.innerHTML = "";
        seccion.innerHTML = "<b> Producto creado </b><br/>";

    } catch (error) {
        console.error("Error:", error);
    } 
}

async function modificar(){
    // Recuperar el token almacenado en el navegador
    const token = localStorage.getItem("jwt");

    if (!token) {
        console.error("No se encuentra el JWT");
        return;
    }

    try {
        const response = await fetch("http://localhost:8090/api/prods/productos/1", {
            method: "PUT",
            headers: {
                "Authorization": `Bearer ${token}`,
                "Accept": "application/json",
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                descripcion: "Prueba modificada",
                precio: 1111
            })
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(
                data.message || data.error_description ||
                data.error || "Error al modificar producto"
            );
        }

        let seccion = document.querySelector("#resultado");
        seccion.innerHTML = "";
        seccion.innerHTML += "<b> Producto modificado </b><br/>";

    } catch (error) {
        console.error("Error:", error);
    } 
}

async function eliminar(){
    // Recuperar el token almacenado en el navegador
    const token = localStorage.getItem("jwt");

    if (!token) {
        console.error("No se encuentra el JWT");
        return;
    }

    try {
        const response = await fetch("http://localhost:8090/api/prods/productos/2", {
            method: "DELETE",
            headers: {
                "Authorization": `Bearer ${token}`,
                "Accept": "application/json",
                "Content-Type": "application/json"
            }
        });

        if (!response.ok) {
            throw new Error(`Error HTTP: ${response.status}`);
        }

        let seccion = document.querySelector("#resultado");
        seccion.innerHTML = "";
        seccion.innerHTML = "<b> Producto eliminado </b><br/>";

    } catch (error) {
        console.error("Error al eliminar productos:", error);
    }
}
			

