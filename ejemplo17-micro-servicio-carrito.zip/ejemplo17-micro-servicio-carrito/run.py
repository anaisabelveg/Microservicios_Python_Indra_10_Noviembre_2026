# Punto de entrada del servidor.

from app import create_app

app = create_app()

if __name__ == "__main__":
    # Arrancar el micro-servicio-carrito en el puerto 8006
    app.run(host="127.0.0.1", port=8006, debug=True)
    