# Implementa las operaciones sobre la logica de negocio

import requests
from app.data import CarritosDAO

dao = CarritosDAO()

def crear_carrito(nombre_usuario):
    carrito = dao.crear(nombre_usuario)
    return carrito
 
    
def consultar(nombre_usuario):
    carrito = dao.buscar_usuario(nombre_usuario)
    
    if carrito is None:
        raise Exception("El carrito no existe")
    
    return carrito


def agregar_pedido(id_producto, cantidad, nombre_usuario):
    carrito = dao.buscar_usuario(nombre_usuario)
    
    if carrito is None:
        raise Exception("El carrito no existe")
    
    url_pedidos = "http://127.0.0.1:8002"
     
    # emito una peticion al micro-servicio-pedidos
    # http://localhost:8002/crear/5/cantidad/78
    respuesta = requests.get(
        f"{url_pedidos}/crear/{id_producto}/cantidad/{cantidad}",
        timeout=5
    )
    
    if respuesta.status_code != 201:
        return{
            "error": "Error al crear el pedido"
        }, 500
        
    pedido = respuesta.json()
    
    carrito = dao.agregar_pedido(nombre_usuario, pedido)
    return carrito


def eliminar_pedido(id_producto, nombre_usuario):
    carrito = dao.sacar_pedido(nombre_usuario, id_producto)
    
    if carrito is None:
            raise Exception("El carrito no existe")
    
    return carrito