# Define los endpoints REST.

from flask import Blueprint, jsonify
from app.services import crear_carrito, consultar, agregar_pedido, eliminar_pedido

carrito_bp = Blueprint("carrito", __name__)

# http://localhost:8006/crear/Pepito (POST)
@carrito_bp.route("/crear/<string:usuario>", methods=["POST"])
def crear(usuario):
    carrito = crear_carrito(usuario)
    return jsonify(carrito.to_dict()), 201

# http://localhost:8006/consultar/Pepito (GET)
@carrito_bp.route("/consultar/<string:usuario>", methods=["GET"])
def consultar_carrito(usuario):
    carrito = consultar(usuario)
    return jsonify(carrito.to_dict()), 200

# http://localhost:8006/agregar/id/4/cantidad/50/usuario/Pepito (PUT)
@carrito_bp.route("/agregar/id/<int:id>/cantidad/<int:cantidad>/usuario/<string:usuario>", methods=["PUT"])
def agregar(id, cantidad, usuario):
    carrito = agregar_pedido(id, cantidad, usuario)
    return jsonify(carrito.to_dict()), 200

# http://localhost:8006/eliminar/id/3/usuario/Pepito (DELETE)
@carrito_bp.route("/eliminar/id/<int:id>/usuario/<string:usuario>", methods=["DELETE"])
def sacar_pedido(id, usuario):
    carrito = eliminar_pedido(id, usuario)
    return jsonify(carrito.to_dict()), 200