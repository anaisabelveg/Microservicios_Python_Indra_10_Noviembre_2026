# Contiene los datos iniciales.
import sqlite3
import json

class Carrito:
    def __init__(self, usuario, contenido, importe):
        self.usuario = usuario
        self.contenido = contenido
        self.importe = importe
        
    def to_dict(self):
        return{
            "nombre": self.usuario,
            "contenido": self.contenido,
            "importe": self.importe
        }

class CarritosDAO:
    def __init__(self, database="carritos.db"):
        self.database = database
        self._crear_tabla()
    
    def crear(self, usuario):
        conexion = self._abrir_conexion()
        cursor = conexion.cursor()
        
        carrito = Carrito(usuario, [], 0.0)
        
        cursor.execute("""
            INSERT INTO carritos (nombre_usuario, contenido, importe)
            VALUES (?,?,?)
        """, (usuario, json.dumps([]), 0.0))
        
        conexion.commit()
        conexion.close()
        
        return carrito
    
    def buscar_usuario(self, usuario):
        conexion = self._abrir_conexion()
        cursor = conexion.cursor()
        
        cursor.execute("""
            SELECT nombre_usuario, contenido, importe 
            FROM carritos
            WHERE nombre_usuario = ?
        """, (usuario,))  # (usuario,) tupla con el valor de los parametros
        
        resultado = cursor.fetchone()        
        conexion.close()
        
        if resultado:
            return Carrito(
                resultado[0],
                json.loads(resultado[1]),
                resultado[2]
            )
        return None
    
    def agregar_pedido(self, usuario, pedido):
        carrito = self.buscar_usuario(usuario)
        
        if carrito is None:
            return None
        
        carrito.contenido.append(pedido)
        importe_pedido = float(pedido["cantidad"]) * float(pedido["producto"]["precio"])
        carrito.importe += importe_pedido
        
        conexion = self._abrir_conexion()
        cursor = conexion.cursor()
        
        cursor.execute("""
            UPDATE carritos 
            SET contenido = ?, importe = ?  
            WHERE nombre_usuario = ?
        """, (json.dumps(carrito.contenido), carrito.importe, usuario))
        
        conexion.commit()
        conexion.close()
        
        return carrito
        
    
    def sacar_pedido(self, usuario, id_producto):
        carrito = self.buscar_usuario(usuario)
                
        if carrito is None:
            return None
        
        pedido_encontrado = next(
            (pedido for pedido in carrito.contenido if pedido["producto"]["id"] == id_producto),
            None
        )
        
        if pedido_encontrado is None:
            return None
        
        carrito.contenido.remove(pedido_encontrado)
        
        importe_pedido = float(pedido_encontrado["cantidad"]) * float(pedido_encontrado["producto"]["precio"])
        carrito.importe -= importe_pedido
        
        conexion = self._abrir_conexion()
        cursor = conexion.cursor()
        
        cursor.execute("""
            UPDATE carritos 
            SET contenido = ?, importe = ?  
            WHERE nombre_usuario = ?
        """, (json.dumps(carrito.contenido), carrito.importe, usuario))
        
        conexion.commit()
        conexion.close()
        
        return carrito
        
    
    def _crear_tabla(self):
        conexion = self._abrir_conexion()
        cursor = conexion.cursor()
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS carritos (
                nombre_usuario TEXT PRIMARY KEY,
                contenido TEXT,
                importe REAL
            )      
        """)
        conexion.commit()
        conexion.close()
    
    def _abrir_conexion(self):
        return sqlite3.connect(self.database)