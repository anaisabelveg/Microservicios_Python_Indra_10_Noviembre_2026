# Implementa las operaciones sobre la logica de negocio

import requests

# Crear la URL base de productos
URL_PRODUCTOS = "http://127.0.0.1:8001/productos"

def crear_pedido(id_producto, cantidad):
    # buscar el producto con ese id
    try:
        # emito una peticion al micro-.servicio-productos
        respuesta = requests.get(
            f"{URL_PRODUCTOS}/{id_producto}",
            timeout=5
        )
        
        # si el producto no existe
        if respuesta.status_code == 404:
            return{
                "error": "producto no encontrado"
            }, 404
            
        # el producto existe
        producto = respuesta.json()
            
    except requests.RequestException:
        return{
            "error": "Microservicio de productos no esta disponible"
        }, 500
    
    # crear el pedido
    pedido = {
        "producto":{
            "id": producto["id"],
            "descripcion": producto["descripcion"],
            "precio": producto["precio"]
        },
        "cantidad": cantidad    
    }
    
    # retornar el pedido
    return pedido, 201