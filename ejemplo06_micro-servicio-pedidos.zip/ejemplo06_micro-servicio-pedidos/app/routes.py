# Define los endpoints REST.

from flask import jsonify, Blueprint
from app.services import crear_pedido

pedidos_bp = Blueprint("pedidos", __name__)

# http://localhost:8002/crear/4/cantidad/100
@pedidos_bp.route("/crear/<int:id_producto>/cantidad/<int:cantidad>", methods=["GET"])
def crear(id_producto, cantidad):
    if cantidad <= 0:
        return jsonify({"error": "La cantidad debe ser mayor que 0"}), 400
    
    pedido, codigo = crear_pedido(id_producto, cantidad)
    
    return jsonify(pedido), codigo