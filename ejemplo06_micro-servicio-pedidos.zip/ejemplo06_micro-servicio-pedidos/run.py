# Punto de entrada del servidor.

from app import create_app

app = create_app()

if __name__ == "__main__":
    # Arrancar el micro-servicio-pedidos en el puerto 8002
    app.run(host="127.0.0.1", port=8002, debug=True)