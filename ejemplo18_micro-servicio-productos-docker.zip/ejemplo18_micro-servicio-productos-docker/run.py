# Punto de entrada del servidor.

from app import create_app

app = create_app()

if __name__ == "__main__":
    # Arrancar el micro-servicio-productos en el puerto 8001
    ''' IMPORTANTE: el host no puede ser 127.0.0.1 porque luego no me permite acceder desde docker '''
    app.run(host="0.0.0.0", port=8001, debug=True)
    
    

