# La puerta de enlace reenvia las peticiones al micro-servicio oportuno

import requests
from flask import jsonify, request, Flask, Response


# Direcciones de los microservicios
SERVICES = {
    "productos": "http://localhost:8001",
    "pedidos": "http://localhost:8002"
}

def enrutar(service_name, path=""):
    # Reenviar la peticion al microservicio correspondiente
    base_url = SERVICES[service_name]
    url = f"{base_url}/{path}"
    
    # Crear un diccionario con las cabeceras q
    
    try:
        response = requests.request(
            method=request.method,
            url=url,
            params=request.args,
            headers=request.headers,
            data=request.get_data(),
            cookies=request.cookies,
            timeout=10,
            allow_redirects=False
        )
        
        return Response(
            response.content,
            status=response.status_code
        )
        
    except requests.RequestException:
        return jsonify({
            "error": f"El microservicio {service_name} no esta disponible"
        }), 502
        

app = Flask(__name__)

''' *************************** Productos ******************************** ''' 
# http://localhost:8090/api/prods/productos
@app.route(
    "/api/prods",
    defaults={"path": ""},
    methods=["GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH"]
)

# http://localhost:8090/api/prods/productos/3
@app.route(
    "/api/prods/<path:path>",
    methods=["GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH"]
)
def productos(path):
    # enrutamos al micro-servicio-productos
    return enrutar("productos", path)


''' *************************** Pedidos ******************************** '''       
# http://localhost:8090/api/pedidos/crear/4/cantidad/100       
@app.route(
    "/api/pedidos/<path:path>",
    methods=["GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH"]
)
def pedidos(path):
    # enrutamos al micro-servicio-pedidos
    return enrutar("pedidos", path)


if __name__ == "__main__":
    # Arrancar la puerta de enlace en el puerto 8090
    app.run(host="127.0.0.1", port=8090, debug=True)