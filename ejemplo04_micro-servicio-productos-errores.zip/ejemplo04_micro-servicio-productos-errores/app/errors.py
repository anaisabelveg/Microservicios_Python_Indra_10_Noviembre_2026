# En este archivo convertimos los errores HTTP (404, 400)
# y las excepciones inesperadas (500) en respuestas JSON

from werkzeug.exceptions import HTTPException
from flask import jsonify


# construir la respuesta
def respuesta_error(codigo, mensaje, estado, detalles=None):
    error = {
        "codigo": codigo,
        "mensaje": mensaje
    }
    
    if detalles is not None:
        error['detalles'] = detalles
        
    return jsonify( {"error": error} ), estado


# registrar los manejadores de errores
def registrar_manejadores(app):
    
    # Errores HTTP: 404, 400, 500
    @app.errorhandler(HTTPException)
    def manejar_error_http(error):
        estado = error.code or 500
        
        errores_conocidos = {
            400: (
                "PETICION_INCORRECTA",
                "La peticion no es valida"
            ),
            404: (
                "RECURSO_NO_ENCONTRADO",
                "Ese recurso no existe"
            )
        }
        
        codigo, mensaje = errores_conocidos.get(
            estado,
            ("ERROR_HTTP", "No se pudo procesar la peticion")
        )
        
        return respuesta_error(codigo, mensaje, estado)