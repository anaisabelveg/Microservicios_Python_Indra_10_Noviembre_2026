# Contiene los datos iniciales.
# Aqui definimos los usuarios y su almacenamiento temporal
# Los password se encriptan con Hash al arrancar el micro-servicio

from werkzeug.security import generate_password_hash, check_password_hash

class User:
    def __init__(self, username, password, roles):
        self.username = username
        self.password_hash = generate_password_hash(password)
        self.roles = list(roles)
        
    def verificar_password(self, password) -> bool:
        return check_password_hash(self.password_hash, password)
    
    def to_dict(self) -> dict:
        return {
            "username": self.username,
            "roles": self.roles
        }
        
        
# Crear un repositorio en memoria para los usuarios       
class UserRepository:
    def __init__(self):
        self._users = {}  # _users es un diccionario private
        self._carga_usuarios()
        
    def _carga_usuarios(self) -> None:
        self.add( User("Juan", "12345", ["usuario"])) 
        self.add( User("Admin", "12345", ["usuario", "admin"])) 
        
    def add(self, user) -> None:
        self._users[user.username] = user
        
    def get_all(self) -> list[User]:
        return list(self._users.values())
    
    def get_by_username(self, username) -> User:
        return self._users.get(username)
    
# Crear una instancia de UserRepository
user_repository = UserRepository()