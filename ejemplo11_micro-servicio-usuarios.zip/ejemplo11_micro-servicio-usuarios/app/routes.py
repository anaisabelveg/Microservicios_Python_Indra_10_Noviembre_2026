# Define los endpoints REST.

from flask import Blueprint, jsonify, request
from app.data import user_repository

usuarios_bp = Blueprint("usuarios", __name__)

# http://localhost:8004/listar (GET)
@usuarios_bp.get("/listar")
def lista_usuarios():
    return jsonify({
        "users": [ user.to_dict() for user in user_repository.get_all()]
    })