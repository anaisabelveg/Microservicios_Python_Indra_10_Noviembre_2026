# Define los endpoints REST.

from flask import Blueprint, jsonify, request
from app.data import user_repository
from app.services import authenticate, crear_token

usuarios_bp = Blueprint("usuarios", __name__)

# http://localhost:8004/auth/login (POST)
@usuarios_bp.post("/auth/login")
def login():
    # recuperamos las credenciales que vienen como un JSON en el cuerpo de la peticion
    data = request.get_json()
    
    # si no recibo los datos retorno un error
    if not isinstance(data, dict):
        return jsonify({
            "error": "Debes proporcionar el username y password"
        }), 400
        
    # Recuperar el username y el password
    username = data.get("username")
    password = data.get("password")
    
    # Autenticamos el usuario con sus credenciales
    user = authenticate(username, password)
    
    # El usuario no esta autenticado
    if user is None:
        return jsonify({
            "error": "Credenciales no validas"
        }), 401
        
    # El usuario esta autenticado y generamos el JWT
    return jsonify({
        "access_token": crear_token(user),
        "token_type": "Bearer",
        "user": user.to_dict()
    }), 200


# http://localhost:8004/listar (GET)
@usuarios_bp.get("/listar")
def lista_usuarios():
    return jsonify({
        "users": [ user.to_dict() for user in user_repository.get_all()]
    })