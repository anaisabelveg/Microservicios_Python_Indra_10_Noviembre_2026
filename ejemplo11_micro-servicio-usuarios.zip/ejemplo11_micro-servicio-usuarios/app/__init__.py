# Crea y configura la aplicación Flask.

from flask import Flask
from app.routes import usuarios_bp

def create_app():
    app = Flask(__name__)
    
    app.register_blueprint(usuarios_bp)
    
    return app