# Crea y configura la aplicación Flask.

from flask import Flask
from app.routes import usuarios_bp
from datetime import timedelta
from flask_jwt_extended import JWTManager
import os

def create_app():
    app = Flask(__name__)
    
    app.config.from_mapping(
        JWT_SECRET_KEY = os.getenv("JWT_SECRET_KEY"),
        JWT_ACCESS_TOKEN_EXPIRES=timedelta(hours=1)
    )
    
    JWTManager(app)
    
    app.register_blueprint(usuarios_bp)
    
    return app