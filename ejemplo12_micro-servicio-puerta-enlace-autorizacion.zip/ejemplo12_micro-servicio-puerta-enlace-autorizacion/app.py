# La puerta de enlace reenvia las peticiones al micro-servicio oportuno

import requests
import os
import jwt
from flask import jsonify, request, Flask, Response
from functools import wraps

JWT_SECRET_KEY = os.getenv("JWT_SECRET_KEY")

# Direcciones de los microservicios
SERVICES = {
    "productos": "http://localhost:8001",
    "pedidos": "http://localhost:8002",
    "usuarios": "http://localhost:8004"
}


def validar_JWT():
    # Validar el JWT y si es valido retorna los datos
    auth_header = request.headers.get("Authorization", "")
    print(auth_header)
    partes = auth_header.split()
    
    # Comprobamos que existe el token
    if len(partes) != 2 or partes[0].lower() != "bearer":
        return None, (jsonify({
            "error": "Falta el token Bearer"
        }), 401)
    
    # Obtengo el token
    token = partes[1]
    
    try:
        # Obtener la informacion del JWT
        payload = jwt.decode(
            token,
            JWT_SECRET_KEY,
            algorithms=["HS256"],
            options={"require": ["exp", "sub"]}
        )
    
    except jwt.ExpiredSignatureError:
        return None, (jsonify({
            "error": "El token ha caducado"
        }), 403)
    except jwt.InvalidTokenError:
        return None, (jsonify({
            "error": "El token no es valido"
        }), 403)
        
    # Obtener los roles del usuario
    roles = payload.get("roles", payload.get("role", []))
    
    return {
        "username": payload["sub"],
        "roles": roles
    }, None
        

def autorizacion_productos(view):
    # Configuramos que operaciones autorizamos segun los roles del usuario
    
    @wraps(view)
    def wrapped(*args, **kwargs):
        user, error = validar_JWT()
        
        if error:
            return error
        
        # recuperamos el metodo HTTP por el que se envia la peticion
        method = request.method.upper()
        
        # necesitamos saber cuales son los roles del usuario
        roles = user["roles"]
          
        
        if method == "GET":
            # Las operaciones de consulta (GET) se lo permitimos a los 2 roles: usuario y admin
            permitido = bool( {"usuario", "admin"} & set(roles) )   # interseccion de conjuntos         
        elif method in {"POST", "PUT", "DELETE", "PATCH"}:
            # Las operaciones de crear (POST), modificar (PUT) y eliminar (DELETE) solo para el role admin
            permitido = "admin" in roles
        else:
            permitido = False
            
        # Si no esta permitido el acceso a productos
        if not permitido:
            return jsonify({
                "error": "No tienes permisos para esta operacion",
                "username": user["username"],
                "method": method
            }), 403
        
        return view(*args, **kwargs)
    return wrapped
   
def autorizacion_pedidos(view):
    # Configuramos que operaciones autorizamos segun los roles del usuario
    
    @wraps(view)
    def wrapped(*args, **kwargs):
        user, error = validar_JWT()
        
        if error:
            return error
        
        # recuperamos el metodo HTTP por el que se envia la peticion
        method = request.method.upper()
        
        # necesitamos saber cuales son los roles del usuario
        roles = user["roles"]
          
        
        if method == "GET":
            # Las operaciones de consulta (GET) se lo permitimos a los 2 roles: usuario y admin
            permitido = bool( {"usuario", "admin"} & set(roles) )   # interseccion de conjuntos         
        else:
            permitido = False
            
        # Si no esta permitido el acceso a productos
        if not permitido:
            return jsonify({
                "error": "No tienes permisos para esta operacion",
                "username": user["username"],
                "method": method
            }), 403
        
        return view(*args, **kwargs)
    return wrapped
  

def enrutar(service_name, path=""):
    # Reenviar la peticion al microservicio correspondiente
    base_url = SERVICES[service_name]
    url = f"{base_url}/{path}"
    
    # Crear un diccionario con las cabeceras q
    
    try:
        response = requests.request(
            method=request.method,
            url=url,
            params=request.args,
            headers=request.headers,
            data=request.get_data(),
            cookies=request.cookies,
            timeout=10,
            allow_redirects=False
        )
        
        return Response(
            response.content,
            status=response.status_code
        )
        
    except requests.RequestException:
        return jsonify({
            "error": f"El microservicio {service_name} no esta disponible"
        }), 502
        

app = Flask(__name__)

''' *************************** Productos ******************************** ''' 
# http://localhost:8090/api/prods/productos
@app.route(
    "/api/prods",
    defaults={"path": ""},
    methods=["GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH"]
)

# http://localhost:8090/api/prods/productos/3
@app.route(
    "/api/prods/<path:path>",
    methods=["GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH"]
)
@autorizacion_productos  # ES MUY IMPORTANTE EL ORDEN (1º rutas, 2º decorador de autorizacion)
def productos(path):
    # enrutamos al micro-servicio-productos
    return enrutar("productos", path)


''' *************************** Pedidos ******************************** '''       
# http://localhost:8090/api/pedidos/crear/4/cantidad/100       
@app.route(
    "/api/pedidos/<path:path>",
    methods=["GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH"]
)
@autorizacion_pedidos
def pedidos(path):
    # enrutamos al micro-servicio-pedidos
    return enrutar("pedidos", path)


''' *************************** Usuarios ******************************** '''       
# http://localhost:8090/api/usuarios/auth/login       
@app.route(
    "/api/usuarios/<path:path>",
    methods=["GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH"]
)
def usuarios(path):
    # enrutamos al micro-servicio-usuarios
    return enrutar("usuarios", path)


if __name__ == "__main__":
    # Arrancar la puerta de enlace en el puerto 8090
    app.run(host="127.0.0.1", port=8090, debug=True)