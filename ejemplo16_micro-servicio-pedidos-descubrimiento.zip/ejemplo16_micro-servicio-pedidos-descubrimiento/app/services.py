# Implementa las operaciones sobre la logica de negocio

import requests
from app.discovery_client import DiscoveryClient

# Crear la URL base de productos
# URL_PRODUCTOS = "http://127.0.0.1:8001/productos"

def crear_pedido(id_producto, cantidad):
    # buscar el producto con ese id
    try:
        # Descubrir que instancias de productos tengo disponibles
        discovery = DiscoveryClient(
            service_name="micro-servicio-pedidos",
            host="127.0.0.1",
            port=8002
        )
        instancias_productos = discovery.obtener_productos()
        
        if not instancias_productos:
            return {
                "error": "El servicio productos no esta disponible"
            }, 503
            
        # Elijo una instancia disponible
        instancia = instancias_productos[0]
        
        # Obtengo la url de productos
        URL_PRODUCTOS = f"http://{instancia['host']}:{instancia['port']}/productos"
        
        # emito una peticion al micro-.servicio-productos
        respuesta = requests.get(
            f"{URL_PRODUCTOS}/{id_producto}",
            timeout=5
        )
        
        # si el producto no existe
        if respuesta.status_code == 404:
            return{
                "error": "producto no encontrado"
            }, 404
            
        # el producto existe
        producto = respuesta.json()
            
    except requests.RequestException:
        return{
            "error": "Microservicio de productos no esta disponible"
        }, 500
    
    # crear el pedido
    pedido = {
        "producto":{
            "id": producto["id"],
            "descripcion": producto["descripcion"],
            "precio": producto["precio"]
        },
        "cantidad": cantidad    
    }
    
    # retornar el pedido
    return pedido, 201