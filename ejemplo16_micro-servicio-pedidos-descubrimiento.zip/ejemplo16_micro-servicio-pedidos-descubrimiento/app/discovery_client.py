# Aqui creamos el proceso para registrar este micro servicio
# en el servicio de descubrimiento

import os
import requests
import logging
import threading

logger = logging.getLogger(__name__)

class DiscoveryClient:
    def __init__(self, service_name, host, port):
        self.discovery_url = os.getenv("DISCOVERY_URL", "http://localhost:8761").rstrip("/")
        self.service_name = service_name
        self.host = host
        self.port = port
        self.instance_id = None
        self.thread = None
        self.stop_event = threading.Event()
        
    def obtener_productos(self):
        response = requests.get(
            f"{self.discovery_url}/services/micro-servicio-productos",
            timeout=5
        )
        response.raise_for_status()
        return response.json()["instances"]
               
    def register(self):
        response = requests.post(
            f"{self.discovery_url}/register",
            json = {
                "service_name": self.service_name,
                "host": self.host,
                "port": self.port
            },
            timeout=5
        )
        response.raise_for_status()
        self.instance_id = response.json()["instance_id"]
        logger.info(
            f"Servicio {self.service_name} registrado con ID {self.instance_id}"
        )
        
    def start(self):
        self.register()
        self.thread = threading.Thread(
            target= self._heartbeat,
            daemon=True
        )
        self.thread.start()
        
    def stop(self):
        self.stop_event.set()
        if self.instance_id:
            try:
                response = requests.delete(
                    f"{self.discovery_url}/register/{self.instance_id}",
                    timeout=5
                )
                response.raise_for_status()
            except requests.RequestException:
                logger.exception("Error al desregistrarlo del servicio descubrimiento")
            
    def _heartbeat(self):
        # mientras que no se pare la instancia, enviamos un heartbeat cada 10 segundos
        while not self.stop_event.wait(10):
            try:
                response = requests.put(
                    f"{self.discovery_url}/heartbeat/{self.instance_id}",
                    timeout=5
                )
                if response.status_code == 404:
                    self.register()
                else:
                    response.raise_for_status()
                    
            except requests.RequestException:
                logger.exception("Error al enviar heartbeat")