# Punto de entrada del servidor.

from app import create_app
from app.discovery_client import DiscoveryClient

app = create_app()

# Crear la instancia de DiscoveryClient
discovery = DiscoveryClient(
    service_name="micro-servicio-pedidos",
    host="127.0.0.1",
    port=8002
)

if __name__ == "__main__":
    
    # Registramos la instancia
    discovery.start()
    
    try:
        # Arrancar el micro-servicio-pedidos en el puerto 8002
        # use_reloader=False necesario para que no registre mas de una instancia
        app.run(host="127.0.0.1", port=8002, debug=True, use_reloader=False)
    
    finally:
        discovery.stop()