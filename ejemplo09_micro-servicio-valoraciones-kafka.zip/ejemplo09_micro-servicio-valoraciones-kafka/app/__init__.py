# Crea y configura la aplicación Flask.

from flask import Flask

def create_app():
    app = Flask(__name__)
    
    return app