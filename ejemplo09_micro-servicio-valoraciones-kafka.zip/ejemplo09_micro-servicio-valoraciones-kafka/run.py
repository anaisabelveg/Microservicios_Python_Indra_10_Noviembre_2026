# Punto de entrada del servidor.

from app import create_app
from app.consumer import consumir_valoraciones
from threading import Thread

app = create_app()

if __name__ == "__main__":
    
    # Crear un hilo para el consumidor
    hilo_consumidor = Thread(
        target=consumir_valoraciones,
        daemon=True
    )
    
    # Arrancamos el hilo
    hilo_consumidor.start()
    
    # Arrancar el micro-servicio-valoraciones en el puerto 8003
    app.run(host="127.0.0.1", port=8003, debug=True, use_reloader=False)