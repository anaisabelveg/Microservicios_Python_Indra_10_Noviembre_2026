from flask import Flask, jsonify

# crear la aplicacion
app = Flask(__name__)

# http://localhost:5000/hola
# Asociar una URL y un metodo HTTP a una funcion
@app.route("/hola", methods=["GET"])
def hola():
    # Queremos que la respuesta sea en formato JSON
    return jsonify( {"mensaje": "Bienvenidos al curso de microservicios con Python y Flask"} )

# Arrancar la aplicacion
if __name__ == "__main__":
    # Arrancar el servidor de desarrollo
    app.run(debug=True)