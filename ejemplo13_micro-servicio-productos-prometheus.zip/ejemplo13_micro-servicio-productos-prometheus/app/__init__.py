# Crea y configura la aplicación Flask.

from flask import Flask
from app.routes import productos_bp
from prometheus_flask_exporter import PrometheusMetrics

def create_app():
    app = Flask(__name__)
    
    app.register_blueprint(
        productos_bp,
        url_prefix = "/productos"  # prefijo de las rutas /productos
    )
    
    # Mostrar las metricas con Prometheus
    PrometheusMetrics(app)
    
    return app